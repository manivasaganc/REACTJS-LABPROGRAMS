[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=24266093&assignment_repo_type=AssignmentRepo)
# ReactJS-Proagram8-Card
Create a Card component that accepts children and displays the content inside the card.
