function createMessage(name, age)
{
  return `Hello ${name}! You are ${age} years old.`;
} 

function displayMessage()
{
  const name=document.getElementById("name").value;
  const age=document.getElementById("age").value;
  document.getElementById("result").textContent=createMessage(name,age);
}
